Hosh 0013
no known bugs or defects 
If you want to use textscan on filename, make args[0] equal to filename in string form.